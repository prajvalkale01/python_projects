from Login.login import MainFrame
if __name__ == "__main__":
    app = MainFrame(None, None, None)
    app.run()